#include <iostream>         // Error handling and output
#include <cstdlib>          // EXIT_FAILURE

#include <GL/glew.h>        // GLEW library
#include "GLFW/glfw3.h"     // GLFW library

// GLM Math Header inclusions
#include <glm/glm.hpp>
#include <glm/gtx/transform.hpp>
#include <glm/gtc/type_ptr.hpp>

#include "SceneManager.h"
#include "ViewManager.h"
#include "ShapeMeshes.h"
#include "ShaderManager.h"

// Namespace for declaring global variables
namespace
{
     // Macro for window title
     const char* const WINDOW_TITLE = "7-1 Final Project and Milestones";

     // Main GLFW window
     GLFWwindow* g_Window = nullptr;

     // Scene, shader, and view managers
     SceneManager* g_SceneManager = nullptr;
     ShaderManager* g_ShaderManager = nullptr;
     ViewManager* g_ViewManager = nullptr;

     // Projection toggle
     bool bProjectionMode = false; // false = perspective, true = orthographic
}

// Function declarations
bool InitializeGLFW();
bool InitializeGLEW();
void ProcessInput(GLFWwindow* window);

/***********************************************************
 *  main(int, char*)
 *
 *  Entry point for the application.
 ***********************************************************/
int main(int argc, char* argv[])
{
     // Initialize GLFW
     if (InitializeGLFW() == false)
     {
          return(EXIT_FAILURE);
     }

     // Create shader manager
     g_ShaderManager = new ShaderManager();

     // Create view manager
     g_ViewManager = new ViewManager(g_ShaderManager);

     // Create the main display window
     g_Window = g_ViewManager->CreateDisplayWindow(WINDOW_TITLE);
     if (!g_Window)
     {
          glfwTerminate();
          return(EXIT_FAILURE);
     }

     // Initialize GLEW
     if (InitializeGLEW() == false)
     {
          return(EXIT_FAILURE);
     }

     // Load shader code
     g_ShaderManager->LoadShaders(
          "../../Utilities/shaders/vertexShader.glsl",
          "../../Utilities/shaders/fragmentShader.glsl");
     g_ShaderManager->use();

     // Create and prepare the scene manager
     g_SceneManager = new SceneManager(g_ShaderManager);
     g_SceneManager->PrepareScene();

     // Main rendering loop
     static bool lastProjectionMode = bProjectionMode; // Tracks projection mode changes
     while (!glfwWindowShouldClose(g_Window))
     {
          // Enable z-depth
          glEnable(GL_DEPTH_TEST);

          // Clear the frame and z buffers
          glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
          glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

          // Process keyboard input for toggling projections and navigation
          ProcessInput(g_Window);

          // Log the projection mode only when it changes
          if (bProjectionMode != lastProjectionMode)
          {
               if (bProjectionMode)
               {
                    std::cout << "INFO: Orthographic Projection Enabled" << std::endl;
               }
               else
               {
                    std::cout << "INFO: Perspective Projection Enabled" << std::endl;
               }
               lastProjectionMode = bProjectionMode;
          }

          // Prepare the 3D scene view
          g_ViewManager->PrepareSceneView();

          // Render the 3D scene
          g_SceneManager->RenderScene();

          // Swap buffers and poll events
          glfwSwapBuffers(g_Window);
          glfwPollEvents();
     }

     // Cleanup
     if (g_SceneManager)
     {
          delete g_SceneManager;
          g_SceneManager = nullptr;
     }
     if (g_ViewManager)
     {
          delete g_ViewManager;
          g_ViewManager = nullptr;
     }
     if (g_ShaderManager)
     {
          delete g_ShaderManager;
          g_ShaderManager = nullptr;
     }

     // Terminate GLFW and exit successfully
     glfwTerminate();
     return EXIT_SUCCESS;
}

/***********************************************************
 *  InitializeGLFW()
 *
 *  Initializes the GLFW library.
 ***********************************************************/
bool InitializeGLFW()
{
     if (!glfwInit())
     {
          std::cerr << "ERROR: Failed to initialize GLFW!" << std::endl;
          return false;
     }

#ifdef __APPLE__
     glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
     glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
     glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
#else
     glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4);
     glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 6);
     glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#endif

     return true;
}

/***********************************************************
 *  InitializeGLEW()
 *
 *  Initializes the GLEW library.
 ***********************************************************/
bool InitializeGLEW()
{
     glewExperimental = GL_TRUE;
     GLenum glewInitResult = glewInit();
     if (glewInitResult != GLEW_OK)
     {
          std::cerr << "ERROR: " << glewGetErrorString(glewInitResult) << std::endl;
          return false;
     }

     // Display OpenGL version
     std::cout << "INFO: OpenGL Version: " << glGetString(GL_VERSION) << std::endl;
     return true;
}

/***********************************************************
 *  ProcessInput(GLFWwindow*)
 *
 *  Handles user input for toggling projection modes and
 *  interacting with the scene.
 ***********************************************************/
void ProcessInput(GLFWwindow* window)
{
     if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
          glfwSetWindowShouldClose(window, true);

     // Toggle projection mode
     if (glfwGetKey(window, GLFW_KEY_O) == GLFW_PRESS)
          bProjectionMode = true; // Orthographic
     if (glfwGetKey(window, GLFW_KEY_P) == GLFW_PRESS)
          bProjectionMode = false; // Perspective

     // Camera movement handled in ViewManager
}
