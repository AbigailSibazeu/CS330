///////////////////////////////////////////////////////////////////////////////
// viewmanager.h
// ============
// manage the viewing of 3D objects within the viewport
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#pragma once

#include "ShaderManager.h"
#include "camera.h"

// GLFW library
#include "GLFW/glfw3.h"

class ViewManager
{
public:
	// Constructor
	ViewManager(ShaderManager* pShaderManager);

	// Destructor
	~ViewManager();

	// Static method for handling mouse position callback
	static void Mouse_Position_Callback(GLFWwindow* window, double xMousePos, double yMousePos);

private:
	// Pointer to ShaderManager object
	ShaderManager* m_pShaderManager;

	// Pointer to active OpenGL display window
	GLFWwindow* m_pWindow;

	// Process keyboard events for user interaction with the scene
	void ProcessKeyboardEvents();

public:
	// Method to create and initialize the OpenGL display window
	GLFWwindow* CreateDisplayWindow(const char* windowTitle);

	// Method to prepare the scene's view and projection matrices
	void PrepareSceneView();
};

